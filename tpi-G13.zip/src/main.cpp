#include <iostream>
#include <fstream>
#include "campo.h"
#include "drone.h"
#include "sistema.h"
#include "tipos.h"
#include "auxiliares.h"

using namespace std;

int main(){
	
    return 0;
}
