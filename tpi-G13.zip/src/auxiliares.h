#ifndef AUX_H
#define AUX_H

//Declaren aqui sus funciones auxiliares globales...

#endif //AUX_H
