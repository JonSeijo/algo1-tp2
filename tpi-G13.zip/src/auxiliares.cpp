#include "auxiliares.h"

//Implementen aqui sus funciones auxiliares globales definidas en auxiliares.h...

